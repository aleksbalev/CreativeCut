<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '59d593e480635489394fcd5bbf369251',
      'native_key' => 'langswitcher',
      'filename' => 'modNamespace/21ec14948dc4243c863d3ef92f4a9838.vehicle',
      'namespace' => 'langswitcher',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => '861cc83a88776fd23de6b1596ddf8f44',
      'native_key' => 14,
      'filename' => 'modPlugin/1d7583c348eb74fcf7124ab9eb02ac8a.vehicle',
      'namespace' => 'langswitcher',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '744545a0f4c8ce8217829671882602a3',
      'native_key' => 1,
      'filename' => 'modCategory/1ae9d3e302316d7c7f64ac40c7c61dfe.vehicle',
      'namespace' => 'langswitcher',
    ),
  ),
);