<?php
$_lang['recaptchav3'] = 'reCaptchaV3';
$_lang['recaptchav3_check_error'] = 'reCAPTCHA error';
$_lang['recaptchav3_check_error_log'] = 'Data Google API ERRORS:';
$_lang['recaptchav3_check_empty_error'] = 'reCAPTCHA field is empty. Please contact with site administrator.';
$_lang['recaptchav3_check_empty_error_log'] = 'reCAPTCHA field is empty. Please check you Formit chunk and browser console.';