=====================
Snippet: SimpleSearch
=====================
Version: 2.1.0
Author: Sterc <modx@sterc.com>
License: GNU GPLv2 (or later at your option)

This is a simple search component. Please see the documentation at:
https://docs.modx.com/extras/revo/simplesearch

Bugs and feature requests
-------------------------
We value your feedback, feature requests and bug reports. Please issue them on GitHub (https://github.com/Sterc/SimpleSearch/issues/new).

Thanks for using SimpleSearch!
