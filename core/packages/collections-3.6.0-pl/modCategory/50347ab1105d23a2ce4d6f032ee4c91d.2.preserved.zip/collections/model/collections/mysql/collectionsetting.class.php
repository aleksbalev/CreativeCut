<?php
/**
 * @package collections
 */
require_once(strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/collectionsetting.class.php');

class CollectionSetting_mysql extends CollectionSetting
{
}
