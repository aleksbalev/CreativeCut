--------------------
dbAdmin
--------------------
Author: Sergey Shlokov <sergant210@bk.ru>
--------------------

A MODx Revolution Extra for database tables administration.

Feel free to suggest ideas/improvements/bugs on GitHub:
http://github.com/sergant210/dbAdmin/issues