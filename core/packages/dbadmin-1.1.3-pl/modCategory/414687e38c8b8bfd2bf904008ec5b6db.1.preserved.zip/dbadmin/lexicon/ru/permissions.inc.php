<?php
/**
 * Russian permissions Lexicon Entries for dbAdmin
 *
 * @package dbadmin
 * @subpackage lexicon
 */
$_lang['tables_list'] = 'Разрешает вывод списка таблиц.';
$_lang['table_view'] = 'Разрешает просмотр таблицы.';
$_lang['table_save'] = 'Разрешает сохранять данные.';
$_lang['table_truncate'] = 'Разрешает удалять записи из таблицы (truncate table).';
$_lang['table_remove'] = 'Разрешает удалять таблицу (remove table).';
$_lang['table_export'] = 'Разрешает экспорт таблицы.';
$_lang['sql_query_execute'] = 'Разрешает выполнение sql запросов.';